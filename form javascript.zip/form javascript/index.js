const studentData = (e) => {
    e.preventDefault();

    let name = document.getElementById("name").value;
    let number = document.getElementById("number").value;
    let course = document.getElementById("course").value;
    let marks = document.getElementById("marks").value;

    let tr = document.createElement("tr");
    let td1 = document.createElement("td");
    td1.innerHTML = name;
    let td2 = document.createElement("td");
    td2.innerHTML = number;
    let td3 = document.createElement("td");
    td3.innerHTML = course;
    let td4 = document.createElement("td");
    td4.innerHTML = marks;
    let td5 = document.createElement("td");
    if (marks >= 90) {
        td5.innerHTML = "Pass"
        td5.style.backgroundColor = "green"
    } else {
        td5.innerHTML = "Fail"
        td5.style.backgroundColor = "red"
    }

    let td6 = document.createElement("td");
    td6.innerHTML = "delete";
    td6.style.color = "red";
    td6.addEventListener("click", (e) => {
        e.target.parentNode.remove();
    })

    tr.append(td1, td2, td3, td4, td5, td6);

    document.getElementById("data").append(tr);

}

const deleteall = () => {
    document.getElementById("data").innerHTMLI = "";
}

document.getElementById("delete").addEventListener("click", deleteall);
document.getElementById("student").addEventListener("submit", studentData);

